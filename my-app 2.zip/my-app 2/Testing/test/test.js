var assert = require('assert');

browser.debug();

	describe('bug hunter', () => {
	it('should have right title of the page', async () => {
		await browser.url('/')
		var title = await browser.getTitle()
		assert.equal(title, 'React App')
		browser.pause(10000)

	});	
		
	it('should have Name tag on page', async () => {
		var firstTag = await $('//*[@id="root"]/div/div[1]')////*[@id="root"]/div/div[1]
		console.log(firstTag.getText())
	});
});